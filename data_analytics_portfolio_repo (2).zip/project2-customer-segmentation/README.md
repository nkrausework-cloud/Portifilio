# Customer Segmentation

**Goal:** Segment customers to tailor marketing campaigns and improve retention.

### 🔧 Tools
- Python (pandas, scikit-learn, matplotlib)
- Jupyter Notebook

### 📊 Process
1. Collected and cleaned customer purchase history.
2. Engineered features (frequency, recency, monetary value).
3. Applied PCA for dimensionality reduction.
4. Clustered customers using K-means.

### 🚀 Insights
- Found 4 distinct customer segments (e.g., "high spend loyalists", "one-time buyers").
- Insights used for targeted campaigns that boosted pilot conversions.

### 📂 Outputs
- `notebooks/segmentation.ipynb`
- `docs/clusters_visualization.png`
