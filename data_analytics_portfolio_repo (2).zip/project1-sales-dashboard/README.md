# Sales Performance Dashboard

**Goal:** Build an interactive dashboard to help business leaders track revenue, top products, and regional sales.

### 🔧 Tools
- SQL (data cleaning & aggregation)
- Tableau or Power BI (dashboard)
- Excel (initial analysis)

### 📊 Process
1. Extracted sales transaction data.
2. Cleaned missing values and standardized categories.
3. Aggregated revenue by region, category, and time period.
4. Built an interactive Tableau/Power BI dashboard.

### 🚀 Insights
- Identified top 3 product categories driving 60% of revenue.
- Found underperforming regions that missed sales targets.

### 📂 Outputs
- [Tableau Public Link](#)
- `notebooks/sales_analysis.ipynb`
- `docs/dashboard_screenshot.png`
