# Churn Prediction Model

**Goal:** Predict which customers are likely to churn so retention strategies can be targeted.

### 🔧 Tools
- Python (pandas, scikit-learn)
- SQL (data extraction)

### 📊 Process
1. Balanced the dataset (SMOTE for class imbalance).
2. Trained Logistic Regression and Random Forest.
3. Evaluated with ROC-AUC, precision/recall, confusion matrix.
4. Exported model for scoring new data.

### 🚀 Insights
- Top churn predictors: usage decline, recent support tickets, payment failures.
- Model achieved 82% ROC-AUC.

### 📂 Outputs
- `notebooks/churn_model.ipynb`
- `docs/roc_curve.png`
