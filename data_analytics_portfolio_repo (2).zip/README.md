# Nicolas Krause — Data Analytics Portfolio

Hi, I’m Nicolas — a transitioning veteran and aspiring **Data Analyst** with a passion for turning raw data into actionable insights. This portfolio showcases projects demonstrating SQL, Python, Tableau/Power BI, and machine learning fundamentals.

## 📂 Projects
1. [Sales Performance Dashboard](project1-sales-dashboard)  
2. [Customer Segmentation](project2-customer-segmentation)  
3. [Churn Prediction Model](project3-churn-prediction)  

## 🔧 Core Skills
- SQL, Python (pandas, scikit-learn)
- Tableau, Power BI, Excel
- Data cleaning, visualization, predictive modeling

## 📫 Contact
- Email: youremail@example.com
- LinkedIn: [linkedin.com/in/yourprofile](#)
- GitHub: [github.com/yourusername](#)
